using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("LocalAppVeyor.Engine.UnitTests")]