﻿namespace LocalAppVeyor.Engine.Configuration
{
    public enum ScriptType
    {
        Batch,
        PowerShell,
        Bash
    }
}
