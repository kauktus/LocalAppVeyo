﻿namespace LocalAppVeyor.Engine.Configuration
{
    public enum BuildVerbosity
    {
        Quiet,
        Minimal,
        Normal,
        Detailed
    }
}