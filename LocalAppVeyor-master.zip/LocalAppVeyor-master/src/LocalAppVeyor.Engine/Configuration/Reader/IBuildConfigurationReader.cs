﻿namespace LocalAppVeyor.Engine.Configuration.Reader
{
    public interface IBuildConfigurationReader
    {
        BuildConfiguration GetBuildConfiguration();
    }
}
