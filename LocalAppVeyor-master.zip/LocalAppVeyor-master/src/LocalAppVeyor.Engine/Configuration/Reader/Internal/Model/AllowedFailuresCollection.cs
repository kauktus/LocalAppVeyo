﻿using System.Collections.ObjectModel;

namespace LocalAppVeyor.Engine.Configuration.Reader.Internal.Model
{
    internal class AllowedFailuresCollection : Collection<AllowedJobFailureConditions>
    {
    }
}