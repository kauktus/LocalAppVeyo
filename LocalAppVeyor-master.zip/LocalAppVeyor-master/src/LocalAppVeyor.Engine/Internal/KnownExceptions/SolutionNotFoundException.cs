﻿using System;

namespace LocalAppVeyor.Engine.Internal.KnownExceptions
{
    public class SolutionNotFoundException : Exception
    {
    }
}
